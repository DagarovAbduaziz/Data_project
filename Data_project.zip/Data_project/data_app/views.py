from django.http import JsonResponse
from django.shortcuts import render
from django.views import View
from django.http import request, response
from .models import Dunyo
# Create your views here.

class DunyoList(View):
    def get(self, request:request):
        data = Dunyo.objects.all()
        response_data = {'result':[]}
        for i in data:
            response_data['result'].append(i.to_dict())
        return render(request, 'home.html', context=response_data)
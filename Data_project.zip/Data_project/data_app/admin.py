from django.contrib import admin
from .models import Dunyo

admin.site.register([Dunyo])

# Register your models here.

from django.db import models

class Dunyo(models.Model):
    materik_name = models.CharField(max_length=50)
    madoni = models.FloatField()
    davlatlar_soni = models.IntegerField() 
    aholi_soni = models.CharField(max_length=200)
    aholi_zichligi = models.CharField(max_length=200)
    iqlimi = models.CharField(max_length=200)
    img = models.CharField(max_length=20000)

    def __str__(self):
        return self.materik_name
    
    def to_dict(self):
        return {
            'materik_name':self.materik_name,
            'madoni':self.madoni,
            'davlatlar_soni':self.davlatlar_soni,
            'aholisi':self.aholi_soni,
            'aholi_zichligi' : self.aholi_zichligi,
            'iqlimi':self.iqlimi,
            'img':self.img
        }

